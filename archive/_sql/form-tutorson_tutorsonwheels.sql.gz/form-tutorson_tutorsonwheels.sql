-- phpMyAdmin SQL Dump
-- version 3.5.8.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 25, 2014 at 08:13 PM
-- Server version: 5.5.40-36.1-log
-- PHP Version: 5.4.23

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tutorson_tutorsonwheels`
--

-- --------------------------------------------------------

--
-- Table structure for table `form`
--

DROP TABLE IF EXISTS `form`;
CREATE TABLE IF NOT EXISTS `form` (
  `iFid` int(11) NOT NULL AUTO_INCREMENT,
  `vDescription` varchar(255) NOT NULL DEFAULT '',
  `vName` varchar(255) NOT NULL DEFAULT '',
  `dDate` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`iFid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `form`
--

INSERT INTO `form` (`iFid`, `vDescription`, `vName`, `dDate`) VALUES
(2, 'Invoice', '1194934696invoice.doc', '2007-11-13'),
(3, 'Sign-in Sheet', '1217281225sign in sheet.doc', '2008-07-28'),
(4, 'Tutor Lesson Log', 'TutorLessonLog.rtf', '2007-05-03');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE IF NOT EXISTS `login` (
  `vName` varchar(25) NOT NULL DEFAULT '',
  `vPass` varchar(50) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`vName`, `vPass`) VALUES
('admin@avileax.com', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `iUid` int(11) NOT NULL AUTO_INCREMENT,
  `vName` varchar(255) NOT NULL DEFAULT '',
  `vPass` varchar(255) NOT NULL DEFAULT '',
  `eStatus` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`iUid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`iUid`, `vName`, `vPass`, `eStatus`) VALUES
(1, 'admin@avileax.com', '21232f297a57a5a743894a0e4a801fc3', '1'),
(3, 'tutor', '1f6f42334e1709a4e0f9922ad789912b', '1');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
