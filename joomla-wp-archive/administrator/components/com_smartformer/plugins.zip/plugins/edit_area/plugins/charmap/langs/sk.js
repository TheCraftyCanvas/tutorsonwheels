editArea.add_lang("sk",{
charmap_but: "Vizuálna klávesnica",
charmap_title: "Vizuálna klávesnica",
charmap_choose_block: "vyber jazykový blok",
charmap_insert: "vlož tento znak"
});
